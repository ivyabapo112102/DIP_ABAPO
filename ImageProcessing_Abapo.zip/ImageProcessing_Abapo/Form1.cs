using System;
using System.Drawing;
using System.Windows.Forms;

namespace ImageProcessing_Abapo
{
    public partial class Form1 : Form
    {
        private Bitmap originalImage;
        private Bitmap processedImage;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png;*.gif|All Files|*.*";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    originalImage = new Bitmap(openFileDialog.FileName);
                    pictureBox1.Image = originalImage;
                }
            }
        }

        private void saveImage_Click(object sender, EventArgs e)
        {
            if (processedImage != null)
            {
                using (SaveFileDialog saveFileDialog = new SaveFileDialog())
                {
                    saveFileDialog.Filter = "BMP Image|*.bmp|JPEG Image|*.jpg|PNG Image|*.png|GIF Image|*.gif";

                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        processedImage.Save(saveFileDialog.FileName);
                    }
                }
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Your code for pictureBox1 Click event
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Your code for pictureBox2 Click event
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Your code for Form1 Load event
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedOption = comboBox1.SelectedItem.ToString();

            switch (selectedOption)
            {
                case "Copy":
                    CopyImage();
                    break;
                case "Greyscale":
                    ApplyGreyscale();
                    break;
                case "Color Inversion":
                    ApplyColorInversion();
                    break;
                case "Histogram":
                    ApplyHistogram();
                    break;
                case "Sepia":
                    ApplySepia();
                    break;
                default:
                    break;
            }
        }

        private void CopyImage()
        {
            if (originalImage != null)
            {
                processedImage = new Bitmap(originalImage);
                pictureBox2.Image = processedImage;
            }
        }

        private void ApplyGreyscale()
        {
            if (originalImage != null)
            {
                processedImage = ApplyFilter(originalImage, ColorToGrayscale);
                pictureBox2.Image = processedImage;
            }
        }

        private void ApplyColorInversion()
        {
            if (originalImage != null)
            {
                processedImage = ApplyFilter(originalImage, InvertColors);
                pictureBox2.Image = processedImage;
            }
        }

        private void ApplyHistogram()
        {
            if (originalImage != null)
            {
                processedImage = ApplyFilter(originalImage, AdjustContrast);
                pictureBox2.Image = processedImage;
            }
        }

        private void ApplySepia()
        {
            if (originalImage != null)
            {
                processedImage = ApplyFilter(originalImage, ApplySepia);
                pictureBox2.Image = processedImage;
            }
        }

        private Bitmap ApplyFilter(Bitmap image, Func<Color, Color> filter)
        {
            Bitmap result = new Bitmap(image.Width, image.Height);

            for (int x = 0; x < image.Width; x++)
            {
                for (int y = 0; y < image.Height; y++)
                {
                    Color originalColor = image.GetPixel(x, y);
                    Color processedColor = filter(originalColor);
                    result.SetPixel(x, y, processedColor);
                }
            }

            return result;
        }

        private Color ColorToGrayscale(Color color)
        {
            int average = (color.R + color.G + color.B) / 3;
            return Color.FromArgb(average, average, average);
        }

        private Color InvertColors(Color color)
        {
            return Color.FromArgb(255 - color.R, 255 - color.G, 255 - color.B);
        }

        private Color AdjustContrast(Color color)
        {
            int factor = 50; // Adjust this value to control the contrast
            return Color.FromArgb(
                Math.Max(0, Math.Min(255, color.R + factor)),
                Math.Max(0, Math.Min(255, color.G + factor)),
                Math.Max(0, Math.Min(255, color.B + factor))
            );
        }

        private Color ApplySepia(Color color)
        {
            int intensity = (int)(0.3 * color.R + 0.59 * color.G + 0.11 * color.B);
            int sepiaR = Math.Min(255, intensity + 40);
            int sepiaG = Math.Min(255, intensity + 20);
            int sepiaB = Math.Min(255, intensity);

            return Color.FromArgb(sepiaR, sepiaG, sepiaB);
        }
    }
}
