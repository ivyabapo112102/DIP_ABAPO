﻿namespace ImageProcessing_Abapo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DisplayImage = new Button();
            comboBox1 = new ComboBox();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            saveImage = new Button();
            exit = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // DisplayImage
            // 
            DisplayImage.Location = new Point(30, 23);
            DisplayImage.Name = "DisplayImage";
            DisplayImage.Size = new Size(157, 33);
            DisplayImage.TabIndex = 0;
            DisplayImage.Text = "Display Image";
            DisplayImage.UseVisualStyleBackColor = true;
            DisplayImage.Click += button1_Click;
            // 
            // comboBox1
            // 
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] { "Copy", "Greyscale", "Color Inversion", "Histogram", "Sepia" });
            this.comboBox1.Location = new System.Drawing.Point(193, 26);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(151, 28);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.Text = "Edit Image";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(79, 99);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(253, 225);
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Location = new Point(363, 101);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(266, 223);
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            pictureBox2.BorderStyle = BorderStyle.FixedSingle;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // saveImage
            // 
            saveImage.Location = new Point(408, 377);
            saveImage.Name = "saveImage";
            saveImage.Size = new Size(94, 29);
            saveImage.TabIndex = 4;
            saveImage.Text = "Save ";
            saveImage.UseVisualStyleBackColor = true;
            saveImage.Click += saveImage_Click;
            // 
            // exit
            // 
            exit.Location = new Point(523, 379);
            exit.Name = "exit";
            exit.Size = new Size(94, 29);
            exit.TabIndex = 5;
            exit.Text = "Exit";
            exit.UseVisualStyleBackColor = true;
            exit.Click += exit_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(exit);
            Controls.Add(saveImage);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(comboBox1);
            Controls.Add(DisplayImage);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button DisplayImage;
        private ComboBox comboBox1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Button saveImage;
        private Button exit;
    }
}